exports.ownershipOwner = require("./ownership-owner.js")
exports.ownershipTransfer = require("./ownership-transfer.js")
