export interface IgetBalance  {
    rpcURl:string
}