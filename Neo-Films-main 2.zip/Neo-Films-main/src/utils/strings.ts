const strings = {
    connet_dialog_title: 'Connect to your wallet',
    connect_dialog_description:
        'Sign in with one of the available providers or create a new one.',
    connect_dialog_note:
        'We do not own your private keys and cannot access your funds without your confirmation.',
};
export default strings;
