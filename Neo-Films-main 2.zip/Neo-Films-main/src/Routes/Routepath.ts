export const Routes = {
  profile: "/profile",
  home: "/",
  LandingPage: "/",
  mint: "/mint",
  duel: "/duel",
  integrate: "/integrate",
  mycollection: "/mycollection",
  rewards: "/rewards",
  faq: "/faq",
};
